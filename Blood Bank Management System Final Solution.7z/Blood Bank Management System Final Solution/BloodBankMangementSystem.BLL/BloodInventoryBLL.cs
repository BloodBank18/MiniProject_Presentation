﻿using BloodBankMangementSystem.DAL;
using BloodBankMangementSystem.Entity;
using BloodBankMangementSystem.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BloodBankMangementSystem.BLL
{
   public class BloodInventoryBLL
    {
        //Display Inventory Details
        public DataTable BloodInventoryDisplay()
        {
            try
            {
                BloodInventoryDL bid = new BloodInventoryDL();
                return bid.BloodInventoryDisplay();
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
        }

        //Delete Inventory Details
        public bool DeleteBloodInventory(DateTime ExpiryDate)
        {
            try
            {
                BloodInventoryDL bid = new BloodInventoryDL();
                return bid.DeleteBloodInventory(ExpiryDate);
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
        }

        //Update Inventory Details
        public bool EditBloodInventory(BloodInventory pobj)
        {
            try
            {
                BloodInventoryDL pd = new BloodInventoryDL();
                return pd.EditBloodInventory(pobj);
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
        }

        //Take all blood bank names from database
        public DataTable GetAllBloodBankName()
        {
            BloodInventoryDL bid = new BloodInventoryDL();
            return bid.GetAllBloodBankName();
        }

        //Search Inventory Details by Inventory ID
        public BloodInventory Search(int searchInventory)
        {
            try
            {
                BloodInventoryDL pd = new BloodInventoryDL();
                return pd.Search(searchInventory);
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
        }

        //transfer blood froom one bank to other bank
        public int TransferBlood(string fromBloodBank, string toBloodBank, int noofBottles,string bloodGroup)
        {
            try
            {
                BloodInventoryDL pd = new BloodInventoryDL();
                return pd.TransferBlood(fromBloodBank, toBloodBank, noofBottles, bloodGroup);
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
        }

        //Get BloodGroup details for transfer
        public DataTable GetRespectiveBloodGroup(string selectedItem)
        {
            try
            {
                BloodInventoryDL dl = new BloodInventoryDL();
                return dl.GetRespectiveBloodGroup(selectedItem);
            }
            catch (Exception)
            {

                throw;
            }
            
        }
    }
}

