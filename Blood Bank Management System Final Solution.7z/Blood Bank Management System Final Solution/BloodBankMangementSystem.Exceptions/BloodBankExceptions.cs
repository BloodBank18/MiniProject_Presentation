﻿using System;
using System.Runtime.Serialization;

namespace BloodBankMangementSystem.Exceptions
{
    [Serializable]
    public class BloodBankExceptions : Exception
    {
        public BloodBankExceptions()
        {
        }

        public BloodBankExceptions(string message) : base(message)
        {
        }

        public BloodBankExceptions(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected BloodBankExceptions(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}